from typing import List, Dict
from models import Student, Classroom  # assuming your classes are in student_classroom.py

class Analytics:
    @staticmethod
    def top_performing_student(classroom: Classroom) -> Student:
        if not classroom._Classroom__students:
            return None
        return max(classroom._Classroom__students, key=lambda s: s.Avrage_Grade())

    @staticmethod
    def lowest_performing_student(classroom: Classroom) -> Student:
        if not classroom._Classroom__students:
            return None
        return min(classroom._Classroom__students, key=lambda s: s.Avrage_Grade())

    @staticmethod
    def rank_students(classroom: Classroom) -> List[Student]:
        return sorted(classroom._Classroom__students, key=lambda s: s.Avrage_Grade(), reverse=True)

    @staticmethod
    def grade_distribution(classroom: Classroom) -> Dict[str, int]:
        distribution = {"excellent": 0, "very good": 0, "good": 0, "pass": 0, "fail": 0}
        for student in classroom._Classroom__students:
            category = student.grade_category()
            distribution[category] += 1
        return distribution