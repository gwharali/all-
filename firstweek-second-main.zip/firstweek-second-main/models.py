class Student:
    def __init__(self,Name:str,Student_id:int,Grades:list):
        self.Name=Name
        self.__Student_id=Student_id
        self.__Grades=Grades
    
    def set_student_id(self,Student_id):
        if(Student_id>0):
            self.__Student_id=Student_id
        else:
            print('the id is invald')
    def get_student_id(self):
        return self.__Student_id

    def add_grade(self,Grades):
        self.__Grades.append(Grades)

    def Get_Grade(self):
        return self.__Grades

    def Avrage_Grade(self):
        if self.__Grades is None:
            return 0
        else:
            return sum(self.__Grades)/len(self.__Grades)
    def grade_category(self):
        grade=self.Avrage_Grade()
        if grade>=90:
            return "excellent"
        elif grade>=80:
            return "very good"
        elif grade>=70:
            return "good"
        elif grade>=50:
            return "pass"
        else:
            return"fall"
    def __str__(self):
        return(f"the student name {self.Name}")

class Classroom:
   def __init__(self):
        self.__students=[]
   def add_student(self,student:Student):
       self.__students.append(student)
    
   def remove_student(self,student_id:int):
        self.__students = [s for s in self.__students if s.get_student_id() != student_id]
   
   def search_student(self,student_id:int)->Student:

        for s in self.__students:
            #print(s.get_student_id())
            if s.get_student_id() == student_id:
                return s
                
        return None
   def calculate_classroom_average(self):
        if not self.__students:
            return 0
        total = sum(student.calculate_average() for student in self.__students)
        return total / len(self.__students)





s1=Student('ali',1,[70,50,70])
grades1=s1.Get_Grade()
cr=Classroom()
cr.add_student(s1)
#cr.remove_student(1)
print(cr.search_student(1))
