import csv
from typing import List
from models import Student


def load_students_from_csv(filename: str) -> List[Student]:
    students = []
    try:
        with open(filename, mode="r", newline="", encoding="utf-8") as file:
            reader = csv.reader(file)
            next(reader)  # تخطي العنوان إذا موجود
            for row in reader:
                if len(row) >= 3:
                    name = row[0]
                    student_id = int(row[1])
                    grades = list(map(int, row[2:]))  # باقي الأعمدة درجات
                    students.append(Student(name, student_id, grades))
    except FileNotFoundError:
        print(f" الملف {filename} غير موجود.")
    return students


def save_students_to_csv(filename: str, students: List[Student]):
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Name", "Student_id", "Grades"])
        for student in students:
            row = [student.Name, student.get_student_id()] + student.Get_Grade()
            writer.writerow(row)


def validate_student_id(student_id: int) -> bool:
    return isinstance(student_id, int) and student_id > 0

def validate_grades(grades: List[int]) -> bool:
    return all(isinstance(g, int) and 0 <= g <= 100 for g in grades)


def average(numbers: List[int]) -> float:
    if not numbers:
        return 0
    return sum(numbers) / len(numbers)

def safe_input(prompt: str, cast_type=int):
    """دالة مساعدة لقراءة مدخلات المستخدم مع تحويل النوع والتحقق"""
    while True:
        try:
            return cast_type(input(prompt))
        except ValueError:
            print(" المدخل غير صالح، حاول مرة أخرى.")