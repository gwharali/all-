from models import Student, Classroom
from analytics import Analytics
from utils import load_students_from_csv, save_students_to_csv, validate_student_id, validate_grades

def main():
    classroom = Classroom()

    while True:
        print("\n===== Classroom Management System =====")
        print("1. Load students from CSV")
        print("2. Add new student")
        print("3. Show top-performing student")
        print("4. Show lowest-performing student")
        print("5. Show student ranking")
        print("6. Show grade distribution")
        print("7. Save students to CSV")
        print("8. Exit")

        choice = input("Enter your choice: ")

        try:
            if choice == "1":
                filename = input("Enter CSV filename: ")
                students = load_students_from_csv(filename)
                for s in students:
                    classroom.add_student(s)
                print(f" Loaded {len(students)} students.")

            elif choice == "2":
                name = input("Enter student name: ")
                student_id = int(input("Enter student ID: "))
                if not validate_student_id(student_id):
                    print(" Invalid student ID.")
                    continue
                grades = list(map(int, input("Enter grades separated by space: ").split()))
                if not validate_grades(grades):
                    print(" Invalid grades.")
                    continue
                classroom.add_student(Student(name, student_id, grades))
                print("✅ Student added successfully.")

            elif choice == "3":
                top = Analytics.top_performing_student(classroom)
                if top:
                    print(f" Top student: {top.Name} (Average: {top.Avrage_Grade():.2f})")
                else:
                    print(" No students available.")

            elif choice == "4":
                low = Analytics.lowest_performing_student(classroom)
                if low:
                    print(f" Lowest student: {low.Name} (Average: {low.Avrage_Grade():.2f})")
                else:
                    print(" No students available.")

            elif choice == "5":
                ranking = Analytics.rank_students(classroom)
                print(" Student Ranking:")
                for i, s in enumerate(ranking, start=1):
                    print(f"{i}. {s.Name} - Average: {s.Avrage_Grade():.2f}")

            elif choice == "6":
                dist = Analytics.grade_distribution(classroom)
                print("Grade Distribution:")
                for category, count in dist.items():
                    print(f"{category}: {count}")

            elif choice == "7":
                filename = input("Enter filename to save: ")
                save_students_to_csv(filename, classroom._Classroom__students)
                print(f" Students saved to {filename}")

            elif choice == "8":
                print(" Exiting program. Goodbye!")
                break

            else:
                print(" Invalid choice, try again.")

        except Exception as e:
            print(f" Error: {e}")

if __name__ == "__main__":
    main()